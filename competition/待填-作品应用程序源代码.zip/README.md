# 衣序 源码包运行说明

本包对应 Android 本地三维试衣和 Python 后端原型。示例人物由几何体程序生成，两件上衣为合成测试件。资产位于 android/app/src/main/assets/local-demo，版本 fixture-anonymous-01。示例可用于加载、拖动旋转、切换上衣和模拟推荐。人物重建实验脚本在 reconstruction，运行时需自行按第三方条件准备 PIXIE、SMPL-X、权重和授权输入。

## Android 本地试衣

打开 Android Studio 并载入 android 目录。同步前准备 Android SDK 37、Gradle Wrapper 所需的 JDK 25（Android 模块 JVM target 21）和可访问依赖仓库的网络。Android 7.0（API 24）及以上设备可安装。保持内置样例目录原样，运行 app。点击进入试衣，拖动旋转，点击浅色与深蓝上衣切换。

命令行在 android 目录运行 gradlew.bat :app:assembleDebug，APK 输出在 app/build/outputs/apk/debug/app-debug.apk。

## Python 后端

在解压根目录打开 PowerShell。准备 Python 3.12 及可访问 PyPI 的环境。

    python -m venv .venv
    $py = '.\.venv\Scripts\python.exe'
    & $py -m pip install -r server/requirements.txt
    & $py -m unittest discover -s server/tests -p 'test_*.py'
    $assets = 'android/app/src/main/assets/local-demo'
    & $py server/validate_asset_package.py $assets
    & $py server/import_package.py $assets
    $env:OOTD_AI_MODE = 'mock'
    & $py -m uvicorn app:app --app-dir server --host 127.0.0.1 --port 8000

另开终端检查 http://127.0.0.1:8000/v1/health 和 http://127.0.0.1:8000/docs。目录接口使用 person_id=person-001。推荐示例使用 request_id=demo-01、person_id=person-001、catalog_version=fixture-anonymous-01、scene=通勤、preference=优先浅色。返回 mode=mock 和 top-001。改为优先深色得到 top-002，改为优先红色得到 no_match。Android 当前从随包资产加载，服务端推荐可单独复现。
